import React, { useState, useEffect } from 'react';

const NewsSection = ({ city, weatherCondition }) => {
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Function to generate mock news data
    const getMockNews = () => {
      setLoading(true);
      
      // Simulate API delay
      setTimeout(() => {
        const weatherNews = [
          {
            id: 1,
            title: `${weatherCondition} weather expected to continue in ${city}`,
            description: `Meteorologists predict the ${weatherCondition.toLowerCase()} conditions will remain in ${city} for the next few days.`,
            source: 'Weather Channel',
            publishedAt: new Date().toLocaleDateString()
          },
          {
            id: 2,
            title: `How the current weather affects ${city}'s local economy`,
            description: `Local businesses in ${city} are adapting to the ongoing ${weatherCondition.toLowerCase()} weather conditions.`,
            source: 'City Economics',
            publishedAt: new Date(Date.now() - 86400000).toLocaleDateString() // Yesterday
          },
          {
            id: 3,
            title: `${city} residents share tips for dealing with ${weatherCondition} conditions`,
            description: `Local residents have been sharing their best advice for handling the ${weatherCondition.toLowerCase()} weather hitting the area.`,
            source: 'Community News',
            publishedAt: new Date(Date.now() - 172800000).toLocaleDateString() // 2 days ago
          }
        ];
        
        const localNews = [
          {
            id: 4,
            title: `${city} announces new community development project`,
            description: `Local officials have unveiled plans for a major development project that aims to improve infrastructure throughout ${city}.`,
            source: 'City News',
            publishedAt: new Date(Date.now() - 259200000).toLocaleDateString() // 3 days ago
          },
          {
            id: 5,
            title: `Annual festival in ${city} draws record crowds`,
            description: `Despite the ${weatherCondition.toLowerCase()} weather, the annual cultural festival in ${city} saw its highest attendance in years.`,
            source: 'Arts & Culture',
            publishedAt: new Date(Date.now() - 345600000).toLocaleDateString() // 4 days ago
          }
        ];
        
        setNews([...weatherNews, ...localNews]);
        setLoading(false);
      }, 800);
    };
    
    // Call the function to get mock news whenever city or weatherCondition changes
    if (city && weatherCondition) {
      getMockNews();
    }
    
  }, [city, weatherCondition]);

  if (loading) {
    return <div className="news-loading">Loading news...</div>;
  }

  return (
    <div className="news-section">
      <h2>Local News for {city}</h2>
      
      {news.length > 0 ? (
        <div className="news-container">
          {news.map(item => (
            <div key={item.id} className="news-card">
              <h3 className="news-title">{item.title}</h3>
              <p className="news-description">{item.description}</p>
              <div className="news-meta">
                <span className="news-source">{item.source}</span>
                <span className="news-date">{item.publishedAt}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="no-news">No news available for this location.</p>
      )}
    </div>
  );
};

export default NewsSection;