import React, { useState } from 'react';

const WeatherApp = () => {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');


  const handleDemoSearch = (e) => {
    e.preventDefault();
    
    if (!city.trim()) return;
    
    setLoading(true);
    setError('');
    
 
    setTimeout(() => {
  
      const mockData = {
        name: city,
        main: {
          temp: Math.floor(Math.random() * 30) + 5, //
          feels_like: Math.floor(Math.random() * 30) + 5,
          humidity: Math.floor(Math.random() * 100),
          pressure: Math.floor(Math.random() * 50) + 1000
        },
        weather: [
          {
            main: ["Clear", "Clouds", "Rain", "Snow"][Math.floor(Math.random() * 4)],
            description: "Weather condition"
          }
        ],
        wind: {
          speed: Math.floor(Math.random() * 20)
        }
      };
      
      setWeather(mockData);
      setLoading(false);
    }, 500);
  };

  return (
    <div className="weather-app">
      <h1>Simple Weather App</h1>
      
      <form onSubmit={handleDemoSearch} className="search-form">
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city name"
          className="search-input"
        />
        <button type="submit" className="search-button">
          Search
        </button>
      </form>
      
      {loading && <div className="loader">Loading...</div>}
      
      {error && <div className="error">{error}</div>}
      
      {weather && (
        <div className="weather-card">
          <h2>{weather.name}</h2>
          <div className="weather-info">
            <div className="temperature">
              <span className="temp-value">{Math.round(weather.main.temp)}°C</span>
              <span className="feels-like">
                Feels like: {Math.round(weather.main.feels_like)}°C
              </span>
            </div>
            
            <div className="weather-condition">
              <div className="condition">{weather.weather[0].main}</div>
              <div className="description">{weather.weather[0].description}</div>
            </div>
            
            <div className="weather-details">
              <div className="detail">
                <span className="label">Humidity:</span>
                <span className="value">{weather.main.humidity}%</span>
              </div>
              <div className="detail">
                <span className="label">Wind:</span>
                <span className="value">{weather.wind.speed} m/s</span>
              </div>
              <div className="detail">
                <span className="label">Pressure:</span>
                <span className="value">{weather.main.pressure} hPa</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WeatherApp;