import React from 'react';
import WeatherApp from './WeatherApp';

function App() {
  return (
    <div className="app">
      <WeatherApp />
    </div>
  );
}

export default App;