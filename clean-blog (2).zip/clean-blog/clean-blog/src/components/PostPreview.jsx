import React from 'react';
import '../css/styles.css'
function PostPreview({ title, subtitle, author, date, link }) {
  
  return (
    <div className="post-preview mb-5">
      <a 
        href={link} 
        className="text-decoration-none text-dark"
      >
        <h2 className="post-title">{title}</h2>
        {subtitle && <h3 className="post-subtitle">{subtitle}</h3>}
      </a>
      <p className="post-meta">
        Posted by <a href="#!" className="text-dark text-decoration-none">{author}</a> on {date}
      </p>
      <hr className="my-4" />
    </div>
  );
}

export default PostPreview;
