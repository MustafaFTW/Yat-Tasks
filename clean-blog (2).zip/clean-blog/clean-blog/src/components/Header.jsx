import React from 'react';
import Navbar from './Navbar';

function Header({ title, subtitle, backgroundImage }) {
  const headerStyle = {
    backgroundImage: `url(${backgroundImage})`,
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    minHeight: '100vh',
    position: 'relative',
    color: 'white'
  };

  const overlayStyle = {
    position: 'absolute', top: 0, bottom: 0, left: 0, right: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)'
  };

  const contentStyle = {
    position: 'relative', zIndex: 1,
    height: 'calc(100vh - 70px)',
    display: 'flex', flexDirection: 'column',
    alignItems: 'center', justifyContent: 'center',
    textAlign: 'center'
  };

  return (
    <header className="masthead" style={headerStyle}>
      <div style={overlayStyle}></div>
      <Navbar />
      <div className="container" style={contentStyle}>
        <h1 className="display-1">{title}</h1>
        <span className="lead">{subtitle}</span>
      </div>
    </header>
  );
}

export default Header;

