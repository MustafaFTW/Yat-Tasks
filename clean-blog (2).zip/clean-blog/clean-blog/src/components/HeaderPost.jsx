import React from 'react';
import Navbar from './Navbar'; // لو عندك Navbar مكون
import '../css/styles.css'
const HeaderPost = ({ title1,title2,title3,title4, subtitle }) => {
  const headerStyle = {
    backgroundImage: "url('assets/img/post-bg.jpg')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    position: "relative",
    height: "100vh",
    color: "white"
  };

  const overlayStyle = {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0, 0, 0, 0.5)"
  };
  

  const contentStyle = {
    position: "relative",
    zIndex: 2,
    padingLeft: '90px',
    top: "50%",
    transform: "translateY(-50%)",
  };

  return (
    <header className="masthead" style={headerStyle}>
      <div style={overlayStyle}></div>
      <Navbar />
      <div className="container" style={contentStyle}>
        <h1 className="display-1">{title1}</h1>
        <h1 className="display-1">{title2}</h1>
        <h1 className="display-1">{title3}</h1>
        <h1 className="display-1">{title4}</h1>
        <span className="lead">{subtitle}</span>
      </div>
    </header>
  );
}

export default HeaderPost;
