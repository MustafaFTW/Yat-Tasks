import React from 'react';
import Header from '../components/Header';
import MainContent from '../components/MainContent';
import Footer from '../components/Footer';
import '../css/styles.css'
function Home() {
  return (
    <div>
      <Header
        title="About Me"
        subtitle="This is what I do."
        backgroundImage="/assets/img/about-bg.jpg"
      />
      <MainContent/>
      <Footer />
    </div>
  );
}

export default Home;
