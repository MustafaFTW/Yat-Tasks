import React from 'react';
import Header from '../components/Header';
import ContactForm from '../components/ContactForm';
import Footer from '../components/Footer';
import '../css/styles.css'
function Home() {
  return (
    <div>
      <Header
        title="Contact Us"
        subtitle="any questions?"
        backgroundImage="/assets/img/contact-bg.jpg"
      />
      <ContactForm/>
      <Footer />
    </div>
  );
}

export default Home;
