import React from 'react';
import Header from '../components/Header';
import PostList from '../components/PostList';
import Footer from '../components/Footer';
import '../css/styles.css'
function Home() {
  return (
    <div>
      <Header
        title="Clean Blog"
        subtitle="A Blog Theme by Bootstrap"
        backgroundImage="/assets/img/home-bg.jpg"
      />
      <PostList />
      <Footer />
    </div>
  );
}

export default Home;
